/*
 * NetworkProcesst.cpp
 *
 *  Created on: 17-Jun-2017
 *      Author: kuhu
 */
#include <iostream>
#include "NetworkProcesst.h"
#include <unistd.h>
#include <list>
using namespace std;

NetworkProcess_t::NetworkProcess_t() {
	// TODO Auto-generated constructor stub

}

// Unused function: It is a single process application; hence not required
void NetworkProcess_t::Create_process()
{


}

// Unused function: handled in NewProcess.cpp file in main() thread
void* Create_thread(void* arg)
{
	return NULL;
}

// Destructor
NetworkProcess_t::~NetworkProcess_t() {
	// TODO Auto-generated destructor stub
}

