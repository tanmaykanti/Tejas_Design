/*
 * ProcessInfot.h
 *
 *  Created on: 17-Jun-2017
 *      Author: kuhu
 */
#include <vector>
#include <fstream>
using namespace std;
#ifndef PROCESSINFOT_H_
#define PROCESSINFOT_H_

class ProcessInfo_t {
	int val[3];
	ifstream openfile;
public:
	ProcessInfo_t();
	void Read_file();
	void Read_node(int);
	void Update_node();
	virtual ~ProcessInfo_t();
};

#endif /* PROCESSINFOT_H_ */
