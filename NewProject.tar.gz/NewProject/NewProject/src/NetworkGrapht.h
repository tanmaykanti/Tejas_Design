/*
 * NetworkGrapht.h
 *
 *  Created on: 17-Jun-2017
 *      Author: kuhu
 */
#include <iostream>
#include <vector>
#include <utility>
#include <algorithm>
#include <list>
#include <stack>
#include <limits.h>
using namespace std;
#ifndef NETWORKGRAPHT_H_
#define NETWORKGRAPHT_H_
#define INF INT_MAX

class AdjListNode
{
        int v;
        int cost;

    public:

        AdjListNode(int _v, int _w)
        {
            v = _v;
            cost = _w;
        }

        int getV()
        {
            return v;
        }

        int getcost()
        {
            return cost;
        }

};

  

class NetworkGraph_t {
    int V; // No. of vertices'


    // Pointer to an array containing adjacency lists

    list<AdjListNode> *adj;

    void topologicalSortUtil(int v, bool visited[], stack<int> &Stack);

public:
	NetworkGraph_t(); //Constructor

	void Create_graph(int);
	// Finds shortest paths from given source vertex
	void Find_shortest_path(int s);
	void Find_minimum_span_tree();
	void Remove_node(int node_v);
	void Reconfigure_graph();

    // function to add an edge to graph
    void addEdge(int u, int v, int cost);

    //Destructor
	virtual ~NetworkGraph_t();
};

#endif /* NETWORKGRAPHT_H_ */
