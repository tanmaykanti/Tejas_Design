/*
 * ProcessInfot.cpp
 *
 *  Created on: 17-Jun-2017
 *      Author: kuhu
 */
#include "NetworkGrapht.h"
#include "ProcessInfot.h"
#include <iostream>
#include <fstream>

using namespace std;
extern 	NetworkGraph_t g;

ProcessInfo_t::ProcessInfo_t() {
// TODO Auto-generated constructor stub

	openfile.open("Info.txt"); // Open file
}

// This function shall read Info.txt file and collect the neighbor information
// For all vertex and add edge info to the vertexes
void ProcessInfo_t::Read_file()
{
	int x;

	if(openfile.is_open()) // check if file is open
	{
		int j=0;
		while(!openfile.eof()) // check if file pointer not at the end
		{
			int i=0;
			// Collect three elements of each line( first being the vertex)
			while(i<3)
			{
			openfile>>x;
			val[i]=x;
			cout<<" "<<val[i];
			i++;
			}
			g.addEdge(val[0],val[1],val[2]); // add edge in the vertex
			j++;
		cout<<endl;
		}
	}
}

// This function shall read the file for a particular node and make it available
// for the thread to monitor
void ProcessInfo_t::Read_node(int n)
{
	int x;
	openfile.seekg(0,ios::beg); // come to the beginning of the file at each entry

	if(openfile.is_open()) // check if file is open
	{
		int j=0;
		while(!openfile.eof()) // check if file pointer not at the end
		{
			int i=0;
			int arr[3]={0,0,0};
			// collect three arguments of each line for the vertex 'n'
			do
			{
				openfile>>x;
				arr[i++]=x;
				if(arr[0]==n)
				cout<<"node:"<<x;
			}while((openfile.peek()!='\n')&& (!openfile.eof()));
		cout<<endl;
		}
	}
}

// Destructor
ProcessInfo_t::~ProcessInfo_t() {
	// TODO Auto-generated destructor stub
}

