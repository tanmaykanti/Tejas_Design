/*
 * NetworkProcesst.h
 *
 *  Created on: 17-Jun-2017
 *      Author: kuhu
 */

#ifndef NETWORKPROCESST_H_
#define NETWORKPROCESST_H_

class NetworkProcess_t {
public:
	NetworkProcess_t();
	void Create_process();
	void* Create_thread(void*);
	void Restart_process();
	void Restart_thread();

	virtual ~NetworkProcess_t();
};

#endif /* NETWORKPROCESST_H_ */
