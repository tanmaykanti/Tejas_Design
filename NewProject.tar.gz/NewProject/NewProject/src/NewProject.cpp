/*
 * main.cpp
 *
 *  Created on: 17-Jun-2017
 *      Author: kuhu
 */
#include <time.h>
#include <sys/time.h>
#include <signal.h>
#include <iostream>
#include <pthread.h>
#include <iostream>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

#include <list>
#include <stack>
#include <limits.h>
#include "NetworkGrapht.h"
#include "ProcessInfot.h"


using namespace std;

NetworkGraph_t g;
ProcessInfo_t p;
pthread_t tdid[6]; // thread ids for each thread
int thr_sts = -1;
// structure to pass thread arguments
struct obj{
	int x;
};

// This is a callback function used by pthread_create()
void* thrd_func(void* arg)
{

	struct obj *pt=(struct obj*)arg;
//	p.Read_node(1);
// continuous loop to keep thread alive
	while(1)
	{

//		cout<<"running thrd id: "<<pt->x<<endl;
		sleep(1);
	}
	return NULL;
}

// This is a callback function used by timer to monitor thread status
void chk_thrd_sts(int arg)
{
	static int id;
	id++;
	id=id%6;
	if(pthread_kill(tdid[id],0)==0)
	{
		cout<<"thread alive, id: "<<id<<endl;
		thr_sts = -1; // update status with negative value
	}
	else
	{
		cout<<"thread dead"<<endl;
		thr_sts= id; // update status with thread id
	}

}

int main()

{
// Create a graph of 6 nodes
	g.Create_graph(6);

// create 6 threads for each nodes
	for(int i=0;i<6;i++)
	{
		struct obj *ptr=new obj;
		ptr->x=i;
	pthread_create(&tdid[i],NULL,thrd_func,(void*)ptr);
	}

// Function call to read the text file to add neighbour information of nodes
	p.Read_file();

// Display shortest path from vertex 1
    int s = 1;
    cout << "Following are shortest distances from source " << s << " \n";
    g.Find_shortest_path(s);

// use timer for monitoring thread status in every 10 seconds
	struct itimerval it;
	it.it_value.tv_sec =1;
	it.it_value.tv_usec =0;
	it.it_interval.tv_sec = 10;
	it.it_interval.tv_usec =0;
	signal(SIGALRM,chk_thrd_sts);
	setitimer(ITIMER_REAL,&it,NULL);

//continuous loop to make main thread alive
    while(1)
    {
//   	cout<<"."<<endl;
    	if(thr_sts != -1) // check thread status for non negative value
    	{
    		g.Remove_node(thr_sts); // remove the node of vertex same as thread status
    		g.Reconfigure_graph(); // reconfigure network graph after removing a node
    	    g.Find_shortest_path(s); // find shortest path again
    	}

    }

    return 0;

}


